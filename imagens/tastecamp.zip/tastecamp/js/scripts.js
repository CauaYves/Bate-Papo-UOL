let receitas = [];

function exibeReceitas(){

    const lista = document.querySelector('.receitas');

    lista.innerHTML = '';

    for(let index = 0; index < receitas.length; index++){

        let template = `
            <li>
                <ion-icon name="fast-food-outline"></ion-icon>
                ${receitas[index].titulo}
            </li>
        `;

        lista.innerHTML = lista.innerHTML + template;
    }

}

pegarReceitasNoServidor();



function pegarReceitasNoServidor(){

    const promise = axios.get('https://instructor-api.sistemas.driven.com.br/projects/tastecamp/receitas');
    promise.then(receitasChegaram);
    promise.catch(deuErroPegarReceitas);

}

function receitasChegaram(resposta){
    console.log('Receitas chegaram!!!!!!');
    console.log(resposta.data);

    receitas = resposta.data;    

    exibeReceitas();
}

function deuErroPegarReceitas(erro){
    console.log('Deu erro ao pergar as Receitas no servidor :(');
    console.log(erro);
}

function adicionarReceita(){    

    // pegar os dados digitados nos inputs
    const tituloReceita = document.querySelector('.nome-receita').value;
    const ingredientesReceita = document.querySelector('.ingredientes-receita').value;
    const preparoReceita = document.querySelector('.modo-preparo-receita').value;

    // criar um novo objeto
    const novaReceita = {
        titulo:tituloReceita,
        ingredientes:ingredientesReceita,
        preparo: preparoReceita
    };
    

    // adcionar o novo objeto no array
    //receitas.push(novaReceita);
    //console.log(receitas);


    // 4- estapas
    // 1 - preciso de uma ferramenta - axios
    // 2 - enviar a cartinha com a nova receita para ser salvo 
    const promessa = axios.post('https://instructor-api.sistemas.driven.com.br/projects/tastecamp/receitas', novaReceita);
    console.log('enviou a nova receita');

    // 3 - pegar a resposta do servidor ( cartinha ) 
    // then agendar a execução de uma função quando os dados (resposta) do servidor chegar e for sucesso!!!!!
    promessa.then(respostaChegou); 
    promessa.catch(deuRuim); // vai agendar a execucao de uma funcao quando der errado!!!!!!
    console.log('esperando o retorno');       
   
    exibeReceitas();
}

function respostaChegou(resposta){
    
    console.log(' resposta do servidor chegou!!!!!!');
    console.log(resposta);

    // 4 - exibir na tela a resposta do servidor
    pegarReceitasNoServidor();
}

function deuRuim(erro){
    console.log('Deu ruim!!! A receita não foi salva!!!!');
    console.log(erro);
}